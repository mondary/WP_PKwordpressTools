<?php
/**
 * Lab : presets de snippets utilitaires perso réutilisables.
 *
 * @package PK_WordPress_Tools
 */

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Lab presets catalogue and one-click install.
 */
class PKWT_Lab {

	/** @var PKWT_Lab|null */
	private static ?PKWT_Lab $instance = null;

	/**
	 * Singleton accessor.
	 */
	public static function instance(): self {
		return self::$instance ??= new self();
	}

	private function __construct() {}

	const ACTIVE_KEY = 'pkwt_active_presets';

	/**
	 * Wire up hooks — exécute le code des presets actifs globalement.
	 */
	public function init(): void {
		add_action( 'after_setup_theme', [ $this, 'run_active_presets' ], 0 );
	}

	/**
	 * Execute every active preset's code.
	 */
	public function run_active_presets(): void {
		$active   = self::get_active();
		$presets  = $this->get_presets();
		foreach ( $active as $slug ) {
			if ( ! isset( $presets[ $slug ] ) ) {
				continue;
			}
			$code = $presets[ $slug ]['code'];
			if ( '' === trim( $code ) ) {
				continue;
			}
			try {
				eval( '?>' . $code );
			} catch ( \Throwable $e ) {
				error_log( sprintf( '[PKWT Lab preset %s] %s', $slug, $e->getMessage() ) );
			}
		}
	}

	/**
	 * Get the list of active preset slugs.
	 */
	public static function get_active(): array {
		$val = get_option( self::ACTIVE_KEY, [] );
		return is_array( $val ) ? $val : [];
	}

	/**
	 * Check if a preset is active.
	 */
	public static function is_active( string $slug ): bool {
		return in_array( $slug, self::get_active(), true );
	}

	/**
	 * Toggle a preset on/off.
	 */
	public static function set_active( string $slug, bool $active ): void {
		$current = self::get_active();
		if ( $active ) {
			if ( ! in_array( $slug, $current, true ) ) {
				$current[] = $slug;
			}
		} else {
			$current = array_values( array_diff( $current, [ $slug ] ) );
		}
		update_option( self::ACTIVE_KEY, $current );
	}

	/**
	 * All available presets.
	 *
	 * Each preset: [
	 *   'slug'        => string,
	 *   'name'        => string,
	 *   'description' => string,
	 *   'category'    => string (Sécurité / Admin / Médias / SEO / Front / Personnalisations),
	 *   'code'        => string (PHP, no <?php tag),
	 * ].
	 */
	public function get_presets(): array {
		return [
			'allow-svg-upload' => [
				'slug'        => 'allow-svg-upload',
				'name'        => __( 'Autoriser l\'upload de SVG', 'pk-wordpress-tools' ),
				'description' => __( 'Ajoute le type MIME SVG à la liste des fichiers téléversables et nettoie le XML à l\'upload.', 'pk-wordpress-tools' ),
				'category'    => __( 'Médias', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_filter( 'upload_mimes', function ( $mimes ) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
} );

add_filter( 'wp_handle_upload_prefilter', function ( $file ) {
    if ( 'image/svg+xml' === ( $file['type'] ?? '' ) ) {
        $doc = new DOMDocument();
        $doc->loadXML( $file['tmp_name'], LIBXML_NOERROR );
        // Strip scripts for safety.
        $scripts = $doc->getElementsByTagName( 'script' );
        foreach ( iterator_to_array( $scripts ) as $s ) {
            $s->parentNode->removeChild( $s );
        }
        $file['tmp_name'] = tempnam( sys_get_temp_dir(), 'svg' ) ?: $file['tmp_name'];
    }
    return $file;
} );
PHP,
			],

			'disable-gutenberg' => [
				'slug'        => 'disable-gutenberg',
				'name'        => __( 'Désactiver Gutenberg (Classic Editor)', 'pk-wordpress-tools' ),
				'description' => __( 'Force l\'éditeur classique TinyMCE partout.', 'pk-wordpress-tools' ),
				'category'    => __( 'Admin', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_filter( 'use_block_editor_for_post_type', '__return_false', 100 );
add_filter( 'use_block_editor_for_post', '__return_false', 100 );
add_filter( 'gutenberg_can_edit_post', '__return_false', 100 );
PHP,
			],

			'disable-comments' => [
				'slug'        => 'disable-comments',
				'name'        => __( 'Désactiver les commentaires & pings', 'pk-wordpress-tools' ),
				'description' => __( 'Ferme les commentaires sur tous les contenus existants et retire les réglages de l\'admin.', 'pk-wordpress-tools' ),
				'category'    => __( 'Personnalisations', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
// Close comments everywhere.
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );

// Remove support for comments / trackbacks everywhere.
add_action( 'init', function () {
    foreach ( get_post_types() as $pt ) {
        if ( post_type_supports( $pt, 'comments' ) ) {
            remove_post_type_support( $pt, 'comments' );
        }
        if ( post_type_supports( $pt, 'trackbacks' ) ) {
            remove_post_type_support( $pt, 'trackbacks' );
        }
    }
} );

// Hide admin menu items for comments.
add_action( 'admin_menu', function () {
    remove_menu_page( 'edit-comments.php' );
} );

// Hide existing admin dashboard widgets related to comments.
add_action( 'wp_dashboard_setup', function () {
    remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
} );
PHP,
			],

			'disable-xmlrpc' => [
				'slug'        => 'disable-xmlrpc',
				'name'        => __( 'Désactiver XML-RPC', 'pk-wordpress-tools' ),
				'description' => __( 'Ferme l\'API XML-RPC pour réduire la surface d\'attaque et bloquer les attaques par brute-force.', 'pk-wordpress-tools' ),
				'category'    => __( 'Sécurité', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'xmlrpc_methods', function ( $m ) {
    return [];
} );
// Remove HTTP header.
add_filter( 'wp_headers', function ( $h ) {
    unset( $h['X-Pingback'] );
    return $h;
} );
PHP,
			],

			'hide-wp-version' => [
				'slug'        => 'hide-wp-version',
				'name'        => __( 'Masquer la version de WordPress', 'pk-wordpress-tools' ),
				'description' => __( 'Retire la meta generator et le numéro de version des scripts/styles chargés.', 'pk-wordpress-tools' ),
				'category'    => __( 'Sécurité', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );

add_filter( 'script_loader_src', function ( $src ) {
    if ( $src && false !== strpos( $src, 'ver=' ) ) {
        $src = remove_query_arg( 'ver', $src );
    }
    return $src;
} );

add_filter( 'style_loader_src', function ( $src ) {
    if ( $src && false !== strpos( $src, 'ver=' ) ) {
        $src = remove_query_arg( 'ver', $src );
    }
    return $src;
} );
PHP,
			],

			'disable-rest-user-enum' => [
				'slug'        => 'disable-rest-user-enum',
				'name'        => __( 'Bloquer l\'énumération d\'utilisateurs via REST', 'pk-wordpress-tools' ),
				'description' => __( 'Retire l\'endpoint /wp-json/wp/v2/users sauf pour les utilisateurs connectés.', 'pk-wordpress-tools' ),
				'category'    => __( 'Sécurité', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_filter( 'rest_endpoints', function ( $endpoints ) {
    if ( ! is_user_logged_in() && isset( $endpoints['/wp/v2/users'] ) ) {
        unset( $endpoints['/wp/v2/users'] );
    }
    if ( ! is_user_logged_in() && isset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] ) ) {
        unset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );
    }
    return $endpoints;
} );

// Block ?author= enumeration.
add_action( 'template_redirect', function () {
    if ( is_admin() ) {
        return;
    }
    if ( ! empty( $_GET['author'] ) && ! is_user_logged_in() ) {
        wp_safe_redirect( home_url(), 301 );
        exit;
    }
} );
PHP,
			],

			'disable-file-edit' => [
				'slug'        => 'disable-file-edit',
				'name'        => __( 'Désactiver l\'éditeur de fichiers du thème/plugins', 'pk-wordpress-tools' ),
				'description' => __( 'Retire l\'éditeur de code intégré de l\'admin (Apparence > Éditeur, Plugins > Éditeur).', 'pk-wordpress-tools' ),
				'category'    => __( 'Sécurité', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
    define( 'DISALLOW_FILE_EDIT', true );
}
if ( ! defined( 'DISALLOW_FILE_MODS' ) ) {
    // Leave false unless you want to fully block plugin/theme updates & install.
    define( 'DISALLOW_FILE_MODS', false );
}
PHP,
			],

			'clean-head' => [
				'slug'        => 'clean-head',
				'name'        => __( 'Nettoyer le <head> (SEO de base)', 'pk-wordpress-tools' ),
				'description' => __( 'Retire emoji, RSD, wlwmanifest, shortlink, REST link, post "rest_link", dns-prefetch — allège le <head>.', 'pk-wordpress-tools' ),
				'category'    => __( 'SEO', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
remove_action( 'template_redirect', 'rest_output_link_header', 11 );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
remove_action( 'wp_head', 'wp_oembed_add_host_js' );

// Remove emoji.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
add_filter( 'tiny_mce_plugins', function ( $p ) {
    return array_filter( $p, static fn( $v ) => 'wpemoji' !== $v );
} );

// DNS prefetch removal.
add_filter( 'emoji_svg_url', '__return_false' );

// Hide generator (also covered by hide-wp-version preset).
remove_action( 'wp_head', 'wp_generator' );
PHP,
			],

			'disable-admin-bar-front' => [
				'slug'        => 'disable-admin-bar-front',
				'name'        => __( 'Cacher la barre admin côté front (sauf admins)', 'pk-wordpress-tools' ),
				'description' => __( 'Désactive l\'affichage de la barre d\'administration côté visiteurs et pour les rôles non-administrateurs.', 'pk-wordpress-tools' ),
				'category'    => __( 'Front', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_filter( 'show_admin_bar', function ( $show ) {
    if ( is_admin() ) {
        return $show;
    }
    return current_user_can( 'manage_options' );
} );
PHP,
			],

			'custom-user-role-editor-contributor' => [
				'slug'        => 'custom-user-role-editor-contributor',
				'name'        => __( 'Rôle « Éditeur contributeur » personnalisé', 'pk-wordpress-tools' ),
				'description' => __( 'Crée un rôle avec un sous-ensemble de caps editor (peut éditer mais pas publier). Idémpotent.', 'pk-wordpress-tools' ),
				'category'    => __( 'Personnalisations', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_action( 'init', function () {
    $role_slug = 'pk_contributor';
    if ( get_role( $role_slug ) ) {
        return; // Idempotent.
    }
    add_role(
        $role_slug,
        __( 'Contributeur éditeur', 'pk-wordpress-tools' ),
        [
            'read'                   => true,
            'edit_posts'             => true,
            'edit_others_posts'      => true,
            'delete_posts'           => true,
            'upload_files'           => true,
            'manage_categories'      => false,
            'publish_posts'          => false,
            'edit_published_posts'   => true,
            'delete_published_posts' => false,
            'edit_pages'             => false,
        ]
    );
} );
PHP,
			],

			'custom-speed-up-admin' => [
				'slug'        => 'custom-speed-up-admin',
				'name'        => __( 'Alléger l\'admin (dashboard widgets & notifications)', 'pk-wordpress-tools' ),
				'description' => __( 'Retire les widgets de tableau de bord inutiles et cache le Welcome panel, QuickPress, etc.', 'pk-wordpress-tools' ),
				'category'    => __( 'Admin', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_action( 'wp_dashboard_setup', function () {
    remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
    remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
    remove_meta_box( 'dashboard_secondary', 'dashboard', 'side' );
    remove_meta_box( 'dashboard_recent_drafts', 'dashboard', 'side' );
    remove_meta_box( 'dashboard_browser_nag', 'dashboard', 'normal' );
    remove_meta_box( 'dashboard_php_nag', 'dashboard', 'normal' );
}, 999 );

// Hide Welcome panel.
remove_action( 'welcome_panel', 'wp_welcome_panel' );
PHP,
			],

			'shortcode-current-year' => [
				'slug'        => 'shortcode-current-year',
				'name'        => __( 'Shortcode [annee]', 'pk-wordpress-tools' ),
				'description' => __( 'Affiche l\'année courante utile pour les copyrights dans le footer.', 'pk-wordpress-tools' ),
				'category'    => __( 'Personnalisations', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_shortcode( 'annee', function () {
    return (string) gmdate( 'Y' );
} );
PHP,
			],

			'disable-woocommerce-analytics' => [
				'slug'        => 'disable-woocommerce-analytics',
				'name'        => __( 'Désactiver WooCommerce Analytics (ordre admin)', 'pk-wordpress-tools' ),
				'description' => __( 'Retire le tableau de bord Analytics de WooCommerce de l\'admin WP.', 'pk-wordpress-tools' ),
				'category'    => __( 'Admin', 'pk-wordpress-tools' ),
				'code'        => <<<'PHP'
add_filter( 'woocommerce_admin_features', function ( $features ) {
    foreach ( [ 'analytics', 'analytics-dashboard', 'analytics-products', 'analytics-orders' ] as $f ) {
        if ( false !== ( $k = array_search( $f, $features, true ) ) ) {
            unset( $features[ $k ] );
        }
    }
    return $features;
} );
PHP,
			],

			'publish-missed-scheduled-posts' => [
				'slug'        => 'publish-missed-scheduled-posts',
				'name'        => __( 'Publier les contenus planifiés manqués', 'pk-wordpress-tools' ),
				'description' => __( 'Toutes les 15 minutes, publie jusqu’à 20 contenus encore planifiés alors que leur date est dépassée.', 'pk-wordpress-tools' ),
				'category'    => __( 'Automatisation', 'pk-wordpress-tools' ),
				'code'        => "add_action( 'init', function () {\n"
					. "    // Limit the recovery query to one run every 15 minutes.\n"
					. "    if ( get_transient( 'pkwt_missed_scheduled_posts_lock' ) ) {\n"
					. "        return;\n"
					. "    }\n\n"
					. "    set_transient( 'pkwt_missed_scheduled_posts_lock', 1, 15 * MINUTE_IN_SECONDS );\n\n"
					. "    global \$wpdb;\n"
					. "    \$post_ids = \$wpdb->get_col(\n"
					. "        \$wpdb->prepare(\n"
					. "            \"SELECT ID FROM {\$wpdb->posts} WHERE post_status = %s AND post_date <= %s ORDER BY post_date ASC LIMIT %d\",\n"
					. "            'future',\n"
					. "            current_time( 'mysql' ),\n"
					. "            20\n"
					. "        )\n"
					. "    );\n\n"
					. "    foreach ( \$post_ids as \$post_id ) {\n"
					. "        wp_publish_post( (int) \$post_id );\n"
					. "    }\n"
					. "} );\n",
			],
		];
	}

	/**
	 * Get one preset by slug.
	 */
	public function get_preset( string $slug ): ?array {
		$presets = $this->get_presets();
		return $presets[ $slug ] ?? null;
	}

	/**
	 * Install a preset as a new snippet (inactive by default).
	 *
	 * @return int The new snippet id or 0 on failure.
	 */
	public function install_preset( string $slug ): int {
		$preset = $this->get_preset( $slug );
		if ( ! $preset ) {
			return 0;
		}
		return PKWT_Snippets::instance()->save_snippet( [
			'name'        => sprintf( '[Lab] %s', $preset['name'] ),
			'description' => $preset['description'],
			'code'        => $preset['code'],
			'active'      => 0,
		] );
	}
}
